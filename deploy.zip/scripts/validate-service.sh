# !/bin/bash
echo "Validating the service"